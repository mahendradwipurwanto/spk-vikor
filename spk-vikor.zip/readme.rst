###################
SPK Vikor
###################

A simple implementation of SPK Vikor method on Sunscreen Products

@ngodingin.indonesia