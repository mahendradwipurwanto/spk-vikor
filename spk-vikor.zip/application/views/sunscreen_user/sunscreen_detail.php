<section class="content-header">
  <h1>Data Sunscreen
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?=site_url('dashboard_user')?>"><i class="fa fa-dashboard"></i> Halaman Utama</a></li>
    <li class="active"><a href="<?=site_url('sunscreen_user')?>"> Data Sunscreen</a></li>
    <li class="active">Detail</li>
  </ol>
</section>

<section class="content">
  <div class="box">
    <div class="box-header">
      <h3 class="box-title"> Detail Sunscreen</h3>
    </div>
    

  </div>

</section>